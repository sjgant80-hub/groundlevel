import { useState, useEffect } from 'react'
import { useRouter } from 'next/router'
import Head from 'next/head'
import { supabase } from '../lib/supabase'

export default function Auth({ user }) {
  const router = useRouter()
  const [isSignup, setIsSignup] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    if (router.query.signup) setIsSignup(true)
    if (user) router.push('/app')
  }, [user, router.query.signup])

  const handleAuth = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setMessage('')

    if (isSignup) {
      const { error } = await supabase.auth.signUp({ email, password })
      if (error) setError(error.message)
      else setMessage('Check your email to confirm your account.')
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) setError(error.message)
      else router.push('/app')
    }
    setLoading(false)
  }

  return (
    <>
      <Head><title>GroundLevel — {isSignup ? 'Sign Up' : 'Sign In'}</title></Head>
      <div style={{ minHeight: '100vh', background: '#0a0a0f', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px' }}>
        <div style={{ width: '100%', maxWidth: 400 }}>

          <div onClick={() => router.push('/')} style={{ fontWeight: 700, fontSize: 20, marginBottom: 48, cursor: 'pointer' }}>
            GROUND<span style={{ color: '#4ade80' }}>LEVEL</span>
          </div>

          <div style={{ fontSize: 9, letterSpacing: '0.4em', color: 'rgba(74,222,128,0.5)', marginBottom: 16, textTransform: 'uppercase' }}>
            {isSignup ? 'Create Account' : 'Sign In'}
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 32 }}>
            {isSignup ? 'Start protecting your rights.' : 'Welcome back.'}
          </h1>

          <form onSubmit={handleAuth} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="Email address"
              required
              style={inputStyle}
            />
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Password"
              required
              style={inputStyle}
            />

            {error && <div style={{ fontSize: 12, color: '#f87171', padding: '10px 14px', border: '1px solid rgba(248,113,113,0.2)' }}>{error}</div>}
            {message && <div style={{ fontSize: 12, color: '#4ade80', padding: '10px 14px', border: '1px solid rgba(74,222,128,0.2)' }}>{message}</div>}

            <button type="submit" disabled={loading} style={{
              padding: '16px',
              background: 'rgba(74,222,128,0.12)',
              border: '1px solid rgba(74,222,128,0.4)',
              color: '#4ade80',
              fontSize: 11,
              letterSpacing: '0.3em',
              cursor: loading ? 'not-allowed' : 'pointer',
              textTransform: 'uppercase',
              marginTop: 8,
            }}>
              {loading ? 'Please wait...' : isSignup ? 'Create Account →' : 'Sign In →'}
            </button>
          </form>

          <div style={{ marginTop: 24, fontSize: 12, color: 'rgba(255,255,255,0.3)', textAlign: 'center' }}>
            {isSignup ? 'Already have an account?' : "Don't have an account?"}
            {' '}
            <span onClick={() => setIsSignup(!isSignup)} style={{ color: '#4ade80', cursor: 'pointer' }}>
              {isSignup ? 'Sign in' : 'Sign up free'}
            </span>
          </div>

          <div onClick={() => router.push('/app')} style={{ marginTop: 32, fontSize: 11, color: 'rgba(255,255,255,0.2)', textAlign: 'center', cursor: 'pointer', letterSpacing: '0.2em' }}>
            Continue without account →
          </div>
        </div>
      </div>
    </>
  )
}

const inputStyle = {
  padding: '14px',
  background: 'rgba(255,255,255,0.03)',
  border: '1px solid rgba(255,255,255,0.08)',
  color: '#fff',
  fontSize: 14,
  outline: 'none',
  width: '100%',
}
