import { useState } from 'react'
import { useRouter } from 'next/router'
import Head from 'next/head'

export default function Home({ user }) {
  const router = useRouter()
  const [email, setEmail] = useState('')

  return (
    <>
      <Head>
        <title>GroundLevel — Know Your Rights</title>
        <meta name="description" content="UK rights protection. Record encounters, detect bluffs, analyse against actual UK law." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <div style={{ minHeight: '100vh', background: '#0a0a0f', color: '#fff', fontFamily: "'Courier New', monospace" }}>

        {/* NAV */}
        <nav style={{ padding: '20px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
          <div style={{ fontSize: 20, fontWeight: 700 }}>
            GROUND<span style={{ color: '#4ade80' }}>LEVEL</span>
          </div>
          <div style={{ display: 'flex', gap: 16 }}>
            {user ? (
              <button onClick={() => router.push('/app')} style={btnStyle('#4ade80')}>
                Open App →
              </button>
            ) : (
              <>
                <button onClick={() => router.push('/auth')} style={ghostBtn}>Sign In</button>
                <button onClick={() => router.push('/auth?signup=true')} style={btnStyle('#4ade80')}>Get Started Free</button>
              </>
            )}
          </div>
        </nav>

        {/* HERO */}
        <div style={{ maxWidth: 680, margin: '0 auto', padding: '80px 24px 60px', textAlign: 'center' }}>
          <div style={{ fontFamily: "'Courier New', monospace", fontSize: 10, letterSpacing: '0.5em', color: 'rgba(74,222,128,0.6)', marginBottom: 24, textTransform: 'uppercase' }}>
            UK Rights Protection
          </div>

          <h1 style={{ fontSize: 'clamp(36px, 7vw, 64px)', fontWeight: 700, lineHeight: 1.1, marginBottom: 24, letterSpacing: '-0.02em' }}>
            The system relies on you<br />
            <span style={{ color: '#4ade80' }}>not knowing your rights.</span>
          </h1>

          <p style={{ fontSize: 16, color: 'rgba(255,255,255,0.45)', lineHeight: 1.8, marginBottom: 40, maxWidth: 520, margin: '0 auto 40px' }}>
            Private security issuing unenforceable fines. PCSOs claiming powers they don't have. Council officers bluffing their authority. GroundLevel levels the playing field.
          </p>

          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button onClick={() => router.push('/app')} style={{ ...btnStyle('#4ade80'), fontSize: 14, padding: '16px 32px' }}>
              ⏺ Start Recording — Free
            </button>
            <button onClick={() => router.push('/auth?signup=true')} style={{ ...ghostBtn, fontSize: 14, padding: '16px 32px' }}>
              Create Account
            </button>
          </div>
        </div>

        {/* FEATURES */}
        <div style={{ maxWidth: 900, margin: '0 auto', padding: '0 24px 80px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 16 }}>
            {[
              { icon: '⏺', title: 'Record Any Encounter', desc: 'One tap recording with timestamp, GPS note and badge number logging. Legally protected in UK public spaces.' },
              { icon: '⚡', title: 'Bluff Detector', desc: '"You must stop filming" — FALSE. Instant verdict on what enforcement officers say. Pre-loaded with 10+ common bluffs.' },
              { icon: '⚖', title: 'AI Legal Analysis', desc: 'Describe what happened. Get a green/amber/red flag, potential violations, and next steps — all grounded in actual UK law.' },
              { icon: '📋', title: 'Complaint Generation', desc: 'One click generates a formal complaint letter to IOPC, SIA, Local Ombudsman — professional, legislation-referenced, ready to send.' },
              { icon: '📊', title: 'Pattern Database', desc: 'Anonymised, aggregated data on badge numbers and organisations. See if others have flagged the same officer.' },
              { icon: '🔒', title: 'Your Records', desc: 'Every encounter stored securely. Timeline of your interactions, complaint status tracking, full history.' },
            ].map(f => (
              <div key={f.title} style={{ padding: '24px', border: '1px solid rgba(255,255,255,0.06)', background: 'rgba(255,255,255,0.01)' }}>
                <div style={{ fontSize: 24, marginBottom: 12 }}>{f.icon}</div>
                <div style={{ fontFamily: "'Courier New', monospace", fontSize: 11, letterSpacing: '0.2em', color: '#4ade80', marginBottom: 8, textTransform: 'uppercase' }}>{f.title}</div>
                <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.4)', lineHeight: 1.7 }}>{f.desc}</div>
              </div>
            ))}
          </div>
        </div>

        {/* PRICING */}
        <div style={{ maxWidth: 600, margin: '0 auto', padding: '0 24px 80px' }}>
          <div style={{ textAlign: 'center', marginBottom: 40 }}>
            <div style={{ fontFamily: "'Courier New', monospace", fontSize: 10, letterSpacing: '0.4em', color: 'rgba(255,255,255,0.2)', textTransform: 'uppercase' }}>Pricing</div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div style={{ padding: '28px', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div style={{ fontSize: 11, letterSpacing: '0.3em', color: 'rgba(255,255,255,0.4)', marginBottom: 16, textTransform: 'uppercase' }}>Free</div>
              <div style={{ fontSize: 36, fontWeight: 700, marginBottom: 4 }}>£0</div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.25)', marginBottom: 20 }}>forever</div>
              {['Record encounters', 'Know your rights', 'Bluff detector', '5 AI analyses/month'].map(f => (
                <div key={f} style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', padding: '6px 0', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>✓ {f}</div>
              ))}
              <button onClick={() => router.push('/app')} style={{ ...ghostBtn, width: '100%', marginTop: 20, padding: '12px' }}>Start Free</button>
            </div>
            <div style={{ padding: '28px', border: '1px solid rgba(74,222,128,0.3)', background: 'rgba(74,222,128,0.03)' }}>
              <div style={{ fontSize: 11, letterSpacing: '0.3em', color: '#4ade80', marginBottom: 16, textTransform: 'uppercase' }}>Pro</div>
              <div style={{ fontSize: 36, fontWeight: 700, marginBottom: 4 }}>£9<span style={{ fontSize: 16, color: 'rgba(255,255,255,0.4)' }}>/mo</span></div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.25)', marginBottom: 20 }}>cancel anytime</div>
              {['Everything in free', 'Unlimited AI analyses', 'Complaint generation', 'Pattern database access', 'Priority legal review'].map(f => (
                <div key={f} style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', padding: '6px 0', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>✓ {f}</div>
              ))}
              <button onClick={() => router.push('/auth?signup=true')} style={{ ...btnStyle('#4ade80'), width: '100%', marginTop: 20, padding: '12px' }}>Get Pro</button>
            </div>
          </div>
        </div>

        {/* FOOTER */}
        <div style={{ padding: '20px 24px', borderTop: '1px solid rgba(255,255,255,0.04)', display: 'flex', justifyContent: 'space-between', fontSize: 10, color: 'rgba(255,255,255,0.15)', letterSpacing: '0.2em' }}>
          <span>GROUNDLEVEL · NOT LEGAL ADVICE</span>
          <span>KNOW YOUR RIGHTS</span>
        </div>
      </div>
    </>
  )
}

const btnStyle = (color) => ({
  padding: '12px 24px',
  background: `${color}15`,
  border: `1px solid ${color}50`,
  color: color,
  fontFamily: "'Courier New', monospace",
  fontSize: 12,
  letterSpacing: '0.2em',
  cursor: 'pointer',
  textTransform: 'uppercase',
  transition: 'all 0.2s',
})

const ghostBtn = {
  padding: '12px 24px',
  background: 'transparent',
  border: '1px solid rgba(255,255,255,0.12)',
  color: 'rgba(255,255,255,0.4)',
  fontFamily: "'Courier New', monospace",
  fontSize: 12,
  letterSpacing: '0.2em',
  cursor: 'pointer',
  textTransform: 'uppercase',
}
