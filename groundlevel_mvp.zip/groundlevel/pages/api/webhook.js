import Stripe from 'stripe'
import { getServiceSupabase } from '../../lib/supabase'
import { buffer } from 'micro'

export const config = { api: { bodyParser: false } }

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()

  const buf = await buffer(req)
  const sig = req.headers['stripe-signature']

  let event
  try {
    event = stripe.webhooks.constructEvent(buf, sig, process.env.STRIPE_WEBHOOK_SECRET)
  } catch (err) {
    return res.status(400).json({ error: `Webhook error: ${err.message}` })
  }

  const supabase = getServiceSupabase()

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object
      const user_id = session.metadata?.user_id
      if (user_id) {
        await supabase.from('profiles').update({
          plan: 'pro',
          stripe_subscription_id: session.subscription,
          subscription_status: 'active',
        }).eq('id', user_id)
      }
      break
    }

    case 'customer.subscription.deleted':
    case 'customer.subscription.updated': {
      const subscription = event.data.object
      const status = subscription.status
      const { data: profile } = await supabase
        .from('profiles')
        .select('id')
        .eq('stripe_subscription_id', subscription.id)
        .single()

      if (profile) {
        await supabase.from('profiles').update({
          plan: status === 'active' ? 'pro' : 'free',
          subscription_status: status,
        }).eq('id', profile.id)
      }
      break
    }
  }

  res.status(200).json({ received: true })
}
