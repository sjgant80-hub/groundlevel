import { getServiceSupabase } from '../../lib/supabase'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()

  const { user_id, encounter_type, badge_number, recording_duration, location_note } = req.body

  if (!user_id) return res.status(400).json({ error: 'user_id required' })

  try {
    const supabase = getServiceSupabase()
    const { data, error } = await supabase
      .from('encounters')
      .insert({
        user_id,
        encounter_type,
        badge_number,
        recording_duration,
        location_note,
        flag: 'amber',
        status: 'recorded',
      })
      .select()
      .single()

    if (error) throw error

    return res.status(200).json({ encounter: data })
  } catch (error) {
    return res.status(500).json({ error: 'Failed to save encounter' })
  }
}
