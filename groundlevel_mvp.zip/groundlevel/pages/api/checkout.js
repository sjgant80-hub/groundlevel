import Stripe from 'stripe'
import { getServiceSupabase } from '../../lib/supabase'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()

  const { user_id, email } = req.body

  try {
    const supabase = getServiceSupabase()

    // Get or create Stripe customer
    let customer_id
    const { data: profile } = await supabase
      .from('profiles')
      .select('stripe_customer_id')
      .eq('id', user_id)
      .single()

    if (profile?.stripe_customer_id) {
      customer_id = profile.stripe_customer_id
    } else {
      const customer = await stripe.customers.create({ email, metadata: { user_id } })
      customer_id = customer.id
      await supabase.from('profiles').update({ stripe_customer_id: customer_id }).eq('id', user_id)
    }

    const session = await stripe.checkout.sessions.create({
      customer: customer_id,
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{ price: process.env.STRIPE_PRO_PRICE_ID, quantity: 1 }],
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard?upgraded=true`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/pricing`,
      metadata: { user_id },
    })

    return res.status(200).json({ url: session.url })

  } catch (error) {
    console.error('Checkout error:', error)
    return res.status(500).json({ error: 'Checkout failed' })
  }
}
