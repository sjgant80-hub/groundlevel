import { getServiceSupabase } from '../../lib/supabase'

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).end()

  const { badge_number } = req.query

  try {
    const supabase = getServiceSupabase()

    if (badge_number) {
      // Look up specific badge number
      const { data } = await supabase
        .from('pattern_flags')
        .select('encounter_type, flag, created_at, organisation')
        .eq('badge_number', badge_number)
        .order('created_at', { ascending: false })

      const redCount = data?.filter(d => d.flag === 'red').length || 0
      const amberCount = data?.filter(d => d.flag === 'amber').length || 0

      return res.status(200).json({
        badge_number,
        total_flags: data?.length || 0,
        red_flags: redCount,
        amber_flags: amberCount,
        risk_level: redCount >= 3 ? 'HIGH' : redCount >= 1 ? 'ELEVATED' : amberCount >= 2 ? 'MODERATE' : 'LOW',
        history: data || [],
      })
    }

    // General stats
    const { data: stats } = await supabase
      .from('pattern_flags')
      .select('flag, encounter_type')

    const total = stats?.length || 0
    const red = stats?.filter(s => s.flag === 'red').length || 0
    const amber = stats?.filter(s => s.flag === 'amber').length || 0

    return res.status(200).json({ total, red, amber, green: total - red - amber })

  } catch (error) {
    return res.status(500).json({ error: 'Failed to fetch patterns' })
  }
}
