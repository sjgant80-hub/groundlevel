import { getServiceSupabase } from '../../lib/supabase'

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).end()

  const { user_id } = req.query
  if (!user_id) return res.status(400).json({ error: 'user_id required' })

  try {
    const supabase = getServiceSupabase()
    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user_id)
      .single()

    const { data: encounters } = await supabase
      .from('encounters')
      .select('id, created_at, encounter_type, flag, summary, badge_number, complaint_worthy, status')
      .eq('user_id', user_id)
      .order('created_at', { ascending: false })
      .limit(50)

    return res.status(200).json({ profile, encounters })
  } catch (error) {
    return res.status(500).json({ error: 'Failed to fetch profile' })
  }
}
