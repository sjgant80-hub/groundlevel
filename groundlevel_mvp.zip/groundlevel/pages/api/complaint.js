import Anthropic from '@anthropic-ai/sdk'
import { getServiceSupabase } from '../../lib/supabase'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()

  const { encounter_id, user_id, encounter_description, badge_number, complaint_body, flag, violations } = req.body

  try {
    // Generate formal complaint letter using Claude
    const message = await anthropic.messages.create({
      model: 'claude-opus-4-6',
      max_tokens: 1500,
      system: `You are a UK civil rights legal writer. Generate a formal, professional complaint letter based on the encounter details. 
      
      The letter should:
      - Be formal and factual
      - Reference specific UK legislation where applicable
      - Request specific remedies
      - Be addressed to the appropriate body
      - Include a request for acknowledgement and reference number
      - Be firm but professional in tone
      
      Return ONLY the letter text, no preamble.`,
      messages: [{
        role: 'user',
        content: `Write a formal complaint letter to ${complaint_body} regarding this encounter:
        
${encounter_description}
${badge_number ? `Badge/ID: ${badge_number}` : ''}
Violations identified: ${violations?.join(', ')}
Flag level: ${flag}`
      }]
    })

    const complaint_text = message.content[0].text

    // Save complaint to DB
    if (user_id && encounter_id) {
      const supabase = getServiceSupabase()
      const { data: complaint } = await supabase
        .from('complaints')
        .insert({
          user_id,
          encounter_id,
          complaint_body,
          complaint_text,
          badge_number,
          status: 'draft',
        })
        .select()
        .single()

      // Update encounter status
      await supabase
        .from('encounters')
        .update({ status: 'complaint_filed' })
        .eq('id', encounter_id)

      return res.status(200).json({ complaint_text, complaint_id: complaint?.id })
    }

    return res.status(200).json({ complaint_text })

  } catch (error) {
    console.error('Complaint error:', error)
    return res.status(500).json({ error: 'Failed to generate complaint' })
  }
}
