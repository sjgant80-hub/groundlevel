import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/router'
import Head from 'next/head'
import { supabase } from '../lib/supabase'
import { ENCOUNTER_TYPES, UK_RIGHTS, BLUFF_PHRASES, FLAG_LEVELS } from '../lib/uklaw'

const TABS = ['Encounter', 'Bluff Check', 'Analyse', 'Records']

export default function App({ user }) {
  const router = useRouter()
  const [tab, setTab] = useState(0)
  const [profile, setProfile] = useState(null)

  // Encounter state
  const [selectedEncounter, setSelectedEncounter] = useState(null)
  const [showRights, setShowRights] = useState(false)
  const [showScript, setShowScript] = useState(false)
  const [recording, setRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const [badgeNumber, setBadgeNumber] = useState('')
  const [locationNote, setLocationNote] = useState('')

  // Bluff state
  const [bluffInput, setBluffInput] = useState('')
  const [bluffResult, setBluffResult] = useState(null)

  // Analyse state
  const [analyseInput, setAnalyseInput] = useState('')
  const [analyseResult, setAnalyseResult] = useState(null)
  const [analyseLoading, setAnalyseLoading] = useState(false)
  const [complaintText, setComplaintText] = useState(null)
  const [complaintLoading, setComplaintLoading] = useState(false)

  // Records state
  const [records, setRecords] = useState([])
  const [recordsLoading, setRecordsLoading] = useState(false)

  const timerRef = useRef(null)

  useEffect(() => {
    if (user) loadProfile()
  }, [user])

  useEffect(() => {
    if (tab === 3) loadRecords()
  }, [tab])

  useEffect(() => {
    if (recording) {
      timerRef.current = setInterval(() => setRecordingTime(t => t + 1), 1000)
    } else {
      clearInterval(timerRef.current)
    }
    return () => clearInterval(timerRef.current)
  }, [recording])

  const loadProfile = async () => {
    const res = await fetch(`/api/profile?user_id=${user.id}`)
    const data = await res.json()
    setProfile(data.profile)
  }

  const loadRecords = async () => {
    if (!user) return
    setRecordsLoading(true)
    const res = await fetch(`/api/profile?user_id=${user.id}`)
    const data = await res.json()
    setRecords(data.encounters || [])
    setRecordsLoading(false)
  }

  const formatTime = (s) => `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`

  const startRecord = () => { setRecording(true); setRecordingTime(0) }

  const stopRecord = async () => {
    setRecording(false)
    if (user && recordingTime > 3) {
      await fetch('/api/save-encounter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: user.id,
          encounter_type: selectedEncounter,
          badge_number: badgeNumber,
          recording_duration: recordingTime,
          location_note: locationNote,
        }),
      })
    }
  }

  const checkBluff = () => {
    if (!bluffInput.trim()) return
    const lower = bluffInput.toLowerCase()
    const match = BLUFF_PHRASES.find(p =>
      lower.includes(p.phrase.toLowerCase().split(' ').slice(0, 3).join(' '))
    )
    setBluffResult(match || {
      phrase: bluffInput,
      verdict: 'UNKNOWN',
      detail: 'Not in our database. Document it and seek advice if you felt coerced.',
      risk: 'low',
    })
  }

  const analyseEncounter = async () => {
    if (!analyseInput.trim()) return
    setAnalyseLoading(true)
    setAnalyseResult(null)
    setComplaintText(null)

    const res = await fetch('/api/analyse', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        description: analyseInput,
        badge_number: badgeNumber,
        encounter_type: selectedEncounter,
        user_id: user?.id,
      }),
    })
    const data = await res.json()
    setAnalyseResult(data)
    setAnalyseLoading(false)
  }

  const generateComplaint = async () => {
    if (!analyseResult) return
    setComplaintLoading(true)
    const res = await fetch('/api/complaint', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        encounter_id: analyseResult.encounter_id,
        user_id: user?.id,
        encounter_description: analyseInput,
        badge_number: badgeNumber,
        complaint_body: analyseResult.complaint_body,
        flag: analyseResult.flag,
        violations: analyseResult.violations,
      }),
    })
    const data = await res.json()
    setComplaintText(data.complaint_text)
    setComplaintLoading(false)
  }

  const rights = selectedEncounter ? UK_RIGHTS[selectedEncounter] : null
  const currentColor = selectedEncounter ? ENCOUNTER_TYPES.find(e => e.id === selectedEncounter)?.color : '#4ade80'

  return (
    <>
      <Head><title>GroundLevel — Know Your Rights</title></Head>
      <div style={{ minHeight: '100vh', background: '#0a0a0f', color: '#fff', fontFamily: "'Courier New', monospace", maxWidth: 520, margin: '0 auto', display: 'flex', flexDirection: 'column' }}>

        {/* HEADER */}
        <div style={{ padding: '16px 20px', borderBottom: '1px solid rgba(255,255,255,0.06)', position: 'sticky', top: 0, zIndex: 10, background: '#0a0a0f' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div onClick={() => router.push('/')} style={{ fontWeight: 700, fontSize: 18, cursor: 'pointer' }}>
              GROUND<span style={{ color: '#4ade80' }}>LEVEL</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              {recording && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 12px', background: 'rgba(248,113,113,0.1)', border: '1px solid rgba(248,113,113,0.3)' }}>
                  <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#f87171', animation: 'pulse-dot 1s infinite' }} />
                  <span style={{ fontSize: 12, color: '#f87171', fontWeight: 700 }}>{formatTime(recordingTime)}</span>
                </div>
              )}
              {user ? (
                <div style={{ fontSize: 9, letterSpacing: '0.2em', color: profile?.plan === 'pro' ? '#fbbf24' : 'rgba(255,255,255,0.2)', textTransform: 'uppercase' }}>
                  {profile?.plan === 'pro' ? '★ PRO' : 'FREE'}
                </div>
              ) : (
                <span onClick={() => router.push('/auth')} style={{ fontSize: 10, color: 'rgba(255,255,255,0.3)', cursor: 'pointer', letterSpacing: '0.2em' }}>SIGN IN</span>
              )}
            </div>
          </div>

          {recording && (
            <div style={{ marginTop: 10, padding: '8px 12px', background: 'rgba(248,113,113,0.06)', border: '1px solid rgba(248,113,113,0.15)', fontSize: 11, color: 'rgba(255,255,255,0.4)', lineHeight: 1.5 }}>
              Recording in public is legal in the UK. You may state: "I am recording this interaction."
            </div>
          )}
        </div>

        {/* TABS */}
        <div style={{ display: 'flex', borderBottom: '1px solid rgba(255,255,255,0.05)', position: 'sticky', top: recording ? 110 : 64, zIndex: 9, background: '#0a0a0f' }}>
          {TABS.map((t, i) => (
            <button key={t} onClick={() => setTab(i)} style={{
              flex: 1, padding: '12px 4px', background: 'transparent', border: 'none',
              borderBottom: `2px solid ${tab === i ? '#4ade80' : 'transparent'}`,
              color: tab === i ? '#4ade80' : 'rgba(255,255,255,0.3)',
              fontSize: 9, letterSpacing: '0.2em', cursor: 'pointer', textTransform: 'uppercase',
            }}>
              {t}
            </button>
          ))}
        </div>

        {/* CONTENT */}
        <div style={{ flex: 1, padding: '20px', overflowY: 'auto' }}>

          {/* ===== ENCOUNTER ===== */}
          {tab === 0 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div style={{ display: 'flex', gap: 10 }}>
                <button onClick={recording ? stopRecord : startRecord} style={{
                  flex: 1, padding: '16px',
                  background: recording ? 'rgba(248,113,113,0.12)' : 'rgba(74,222,128,0.08)',
                  border: `2px solid ${recording ? '#f87171' : '#4ade80'}`,
                  color: recording ? '#f87171' : '#4ade80',
                  fontSize: 11, letterSpacing: '0.3em', cursor: 'pointer', fontWeight: 700, textTransform: 'uppercase',
                }}>
                  {recording ? '⬛ STOP RECORDING' : '⏺ RECORD ENCOUNTER'}
                </button>
              </div>

              <div>
                <div style={labelStyle}>Badge / ID Number</div>
                <input value={badgeNumber} onChange={e => setBadgeNumber(e.target.value)} placeholder="e.g. PC 1234" style={inputStyle} />
              </div>

              <div>
                <div style={labelStyle}>Location Note</div>
                <input value={locationNote} onChange={e => setLocationNote(e.target.value)} placeholder="e.g. Outside Tesco, High Street" style={inputStyle} />
              </div>

              <div>
                <div style={labelStyle}>Encounter Type</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                  {ENCOUNTER_TYPES.map(type => (
                    <button key={type.id} onClick={() => { setSelectedEncounter(type.id); setShowRights(true); setShowScript(false) }} style={{
                      padding: '12px', textAlign: 'left', cursor: 'pointer',
                      background: selectedEncounter === type.id ? `${type.color}12` : 'rgba(255,255,255,0.02)',
                      border: `1px solid ${selectedEncounter === type.id ? type.color + '50' : 'rgba(255,255,255,0.06)'}`,
                      color: selectedEncounter === type.id ? type.color : 'rgba(255,255,255,0.4)',
                      transition: 'all 0.2s',
                    }}>
                      <div style={{ fontSize: 18, marginBottom: 4 }}>{type.icon}</div>
                      <div style={{ fontSize: 10, letterSpacing: '0.1em' }}>{type.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {showRights && rights && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <div style={{ padding: '14px', background: 'rgba(74,222,128,0.05)', border: '1px solid rgba(74,222,128,0.2)', borderLeft: '3px solid #4ade80' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div style={{ fontSize: 9, letterSpacing: '0.3em', color: '#4ade80', textTransform: 'uppercase' }}>📢 Say This</div>
                      <button onClick={() => setShowScript(!showScript)} style={{ background: 'transparent', border: 'none', color: '#4ade80', cursor: 'pointer', fontSize: 9, letterSpacing: '0.2em' }}>
                        {showScript ? 'HIDE' : 'SHOW'}
                      </button>
                    </div>
                    {showScript && <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.75)', lineHeight: 1.7, marginTop: 10, fontStyle: 'italic' }}>"{rights.script}"</div>}
                  </div>

                  <div style={{ padding: '14px', border: '1px solid rgba(248,113,113,0.15)', background: 'rgba(248,113,113,0.03)' }}>
                    <div style={{ fontSize: 9, letterSpacing: '0.3em', color: '#f87171', marginBottom: 8, textTransform: 'uppercase' }}>✗ They CANNOT</div>
                    {rights.cannotDo.map((item, i) => (
                      <div key={i} style={{ fontSize: 12, color: 'rgba(255,255,255,0.55)', lineHeight: 1.6, padding: '4px 0', borderBottom: i < rights.cannotDo.length - 1 ? '1px solid rgba(255,255,255,0.04)' : 'none' }}>{item}</div>
                    ))}
                  </div>

                  <div style={{ padding: '14px', border: '1px solid rgba(74,222,128,0.15)', background: 'rgba(74,222,128,0.03)' }}>
                    <div style={{ fontSize: 9, letterSpacing: '0.3em', color: '#4ade80', marginBottom: 8, textTransform: 'uppercase' }}>✓ Your Rights</div>
                    {rights.yourRights.map((item, i) => (
                      <div key={i} style={{ fontSize: 12, color: 'rgba(255,255,255,0.55)', lineHeight: 1.6, padding: '4px 0', borderBottom: i < rights.yourRights.length - 1 ? '1px solid rgba(255,255,255,0.04)' : 'none' }}>{item}</div>
                    ))}
                  </div>

                  <div style={{ padding: '10px 14px', background: 'rgba(255,255,255,0.01)', border: '1px solid rgba(255,255,255,0.04)' }}>
                    <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.2)', marginBottom: 4, letterSpacing: '0.3em', textTransform: 'uppercase' }}>Legislation</div>
                    <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.3)', lineHeight: 1.6 }}>{rights.legislation}</div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ===== BLUFF CHECK ===== */}
          {tab === 1 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div style={labelStyle}>What did they say?</div>
              <textarea value={bluffInput} onChange={e => setBluffInput(e.target.value)} placeholder='"You have to give me your name"' rows={3} style={{ ...inputStyle, resize: 'none', lineHeight: 1.6 }} />
              <button onClick={checkBluff} style={{
                padding: '14px', cursor: bluffInput.trim() ? 'pointer' : 'not-allowed',
                background: bluffInput.trim() ? 'rgba(251,191,36,0.1)' : 'rgba(255,255,255,0.02)',
                border: `1px solid ${bluffInput.trim() ? 'rgba(251,191,36,0.35)' : 'rgba(255,255,255,0.05)'}`,
                color: bluffInput.trim() ? '#fbbf24' : 'rgba(255,255,255,0.2)',
                fontSize: 10, letterSpacing: '0.3em', textTransform: 'uppercase',
              }}>
                Check The Bluff →
              </button>

              {bluffResult && (
                <div style={{ padding: '20px', border: `1px solid ${bluffResult.risk === 'high' ? 'rgba(248,113,113,0.35)' : 'rgba(251,191,36,0.25)'}`, background: bluffResult.risk === 'high' ? 'rgba(248,113,113,0.06)' : 'rgba(251,191,36,0.04)' }} className="fade-in">
                  <div style={{ fontSize: 20, fontWeight: 700, color: bluffResult.risk === 'high' ? '#f87171' : bluffResult.risk === 'medium' ? '#fbbf24' : 'rgba(255,255,255,0.3)', letterSpacing: '0.2em', marginBottom: 12 }}>
                    {bluffResult.verdict}
                  </div>
                  <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.6)', lineHeight: 1.7 }}>{bluffResult.detail}</div>
                </div>
              )}

              <div style={{ marginTop: 8 }}>
                <div style={{ ...labelStyle, marginBottom: 10 }}>Common Bluffs</div>
                {BLUFF_PHRASES.map((b, i) => (
                  <div key={i} onClick={() => { setBluffInput(b.phrase); setBluffResult(b) }} style={{ padding: '10px 14px', marginBottom: 4, border: '1px solid rgba(255,255,255,0.05)', background: 'rgba(255,255,255,0.01)', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.4)', fontStyle: 'italic' }}>"{b.phrase}"</div>
                    <div style={{ fontSize: 9, letterSpacing: '0.2em', color: b.risk === 'high' ? '#f87171' : '#fbbf24', fontWeight: 700 }}>{b.verdict}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ===== ANALYSE ===== */}
          {tab === 2 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div style={labelStyle}>Describe what happened</div>
              <textarea value={analyseInput} onChange={e => setAnalyseInput(e.target.value)} placeholder="Describe the encounter in detail — what was said, what they did, how long it lasted, what you were doing..." rows={6} style={{ ...inputStyle, resize: 'none', lineHeight: 1.6 }} />
              <button onClick={analyseEncounter} disabled={analyseLoading || !analyseInput.trim()} style={{
                padding: '16px', cursor: analyseInput.trim() && !analyseLoading ? 'pointer' : 'not-allowed',
                background: analyseInput.trim() && !analyseLoading ? 'rgba(74,222,128,0.1)' : 'rgba(255,255,255,0.02)',
                border: `1px solid ${analyseInput.trim() && !analyseLoading ? 'rgba(74,222,128,0.35)' : 'rgba(255,255,255,0.05)'}`,
                color: analyseInput.trim() && !analyseLoading ? '#4ade80' : 'rgba(255,255,255,0.2)',
                fontSize: 10, letterSpacing: '0.3em', textTransform: 'uppercase', transition: 'all 0.2s',
              }}>
                {analyseLoading ? 'Analysing against UK law...' : 'Analyse Encounter →'}
              </button>

              {analyseResult && !analyseResult.error && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }} className="fade-in">
                  <div style={{ padding: '20px', background: FLAG_LEVELS[analyseResult.flag]?.bg, border: `1px solid ${FLAG_LEVELS[analyseResult.flag]?.color}35`, display: 'flex', alignItems: 'center', gap: 16 }}>
                    <div style={{ width: 44, height: 44, borderRadius: '50%', background: `${FLAG_LEVELS[analyseResult.flag]?.color}15`, border: `2px solid ${FLAG_LEVELS[analyseResult.flag]?.color}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, flexShrink: 0 }}>
                      {analyseResult.flag === 'green' ? '✓' : analyseResult.flag === 'amber' ? '⚠' : '✗'}
                    </div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: FLAG_LEVELS[analyseResult.flag]?.color, letterSpacing: '0.2em', marginBottom: 4 }}>{FLAG_LEVELS[analyseResult.flag]?.label}</div>
                      <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', lineHeight: 1.5 }}>{analyseResult.summary}</div>
                    </div>
                  </div>

                  {analyseResult.violations?.length > 0 && (
                    <div style={{ padding: '14px', border: '1px solid rgba(248,113,113,0.2)', background: 'rgba(248,113,113,0.04)' }}>
                      <div style={{ fontSize: 9, letterSpacing: '0.3em', color: '#f87171', marginBottom: 8, textTransform: 'uppercase' }}>Potential Violations</div>
                      {analyseResult.violations.map((v, i) => <div key={i} style={{ fontSize: 12, color: 'rgba(255,255,255,0.55)', lineHeight: 1.6, padding: '3px 0' }}>⚠ {v}</div>)}
                    </div>
                  )}

                  <div style={{ padding: '14px', border: '1px solid rgba(96,165,250,0.15)', background: 'rgba(96,165,250,0.03)' }}>
                    <div style={{ fontSize: 9, letterSpacing: '0.3em', color: '#60a5fa', marginBottom: 8, textTransform: 'uppercase' }}>Next Steps</div>
                    {analyseResult.next_steps?.map((s, i) => <div key={i} style={{ fontSize: 12, color: 'rgba(255,255,255,0.55)', lineHeight: 1.6, padding: '3px 0' }}>{i + 1}. {s}</div>)}
                  </div>

                  {analyseResult.complaint_worthy && (
                    <div style={{ padding: '16px', background: 'rgba(252,211,77,0.05)', border: '1px solid rgba(252,211,77,0.25)' }}>
                      <div style={{ fontSize: 9, letterSpacing: '0.3em', color: '#fcd34d', marginBottom: 6, textTransform: 'uppercase' }}>⚡ Complaint Recommended</div>
                      <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', marginBottom: 14 }}>
                        File with: <strong style={{ color: '#fcd34d' }}>{analyseResult.complaint_body}</strong>
                      </div>

                      {!complaintText ? (
                        <button onClick={user ? generateComplaint : () => router.push('/auth')} disabled={complaintLoading} style={{
                          width: '100%', padding: '12px', cursor: 'pointer',
                          background: 'rgba(252,211,77,0.1)', border: '1px solid rgba(252,211,77,0.3)',
                          color: '#fcd34d', fontSize: 10, letterSpacing: '0.3em', textTransform: 'uppercase',
                        }}>
                          {complaintLoading ? 'Generating complaint...' : user ? 'Generate Complaint Letter →' : 'Sign in to Generate Complaint →'}
                        </button>
                      ) : (
                        <div>
                          <div style={{ fontSize: 9, letterSpacing: '0.3em', color: '#4ade80', marginBottom: 10, textTransform: 'uppercase' }}>✓ Complaint Generated</div>
                          <div style={{ padding: '14px', background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)', fontSize: 12, color: 'rgba(255,255,255,0.55)', lineHeight: 1.8, whiteSpace: 'pre-wrap', maxHeight: 300, overflowY: 'auto' }}>
                            {complaintText}
                          </div>
                          <button onClick={() => navigator.clipboard?.writeText(complaintText)} style={{ width: '100%', marginTop: 8, padding: '10px', background: 'transparent', border: '1px solid rgba(74,222,128,0.2)', color: '#4ade80', cursor: 'pointer', fontSize: 9, letterSpacing: '0.3em', textTransform: 'uppercase' }}>
                            Copy to Clipboard
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {analyseResult?.error && <div style={{ padding: '14px', border: '1px solid rgba(248,113,113,0.2)', color: '#f87171', fontSize: 12 }}>{analyseResult.error}</div>}
            </div>
          )}

          {/* ===== RECORDS ===== */}
          {tab === 3 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {!user ? (
                <div style={{ textAlign: 'center', padding: '40px 20px' }}>
                  <div style={{ fontSize: 32, marginBottom: 16, opacity: 0.3 }}>🔒</div>
                  <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.3)', marginBottom: 20, lineHeight: 1.7 }}>Sign in to save and view your encounter records.</div>
                  <button onClick={() => router.push('/auth')} style={{ padding: '12px 24px', background: 'rgba(74,222,128,0.1)', border: '1px solid rgba(74,222,128,0.3)', color: '#4ade80', cursor: 'pointer', fontSize: 10, letterSpacing: '0.3em', textTransform: 'uppercase' }}>
                    Sign In / Sign Up
                  </button>
                </div>
              ) : recordsLoading ? (
                <div style={{ textAlign: 'center', padding: '40px', color: 'rgba(255,255,255,0.2)', fontSize: 12 }}>Loading...</div>
              ) : records.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '40px 20px' }}>
                  <div style={{ fontSize: 32, marginBottom: 12, opacity: 0.3 }}>📋</div>
                  <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.2)', lineHeight: 1.7 }}>No encounters recorded yet.</div>
                </div>
              ) : (
                <>
                  <div style={{ fontSize: 9, letterSpacing: '0.3em', color: 'rgba(255,255,255,0.2)', textTransform: 'uppercase' }}>{records.length} Encounters</div>
                  {records.map(r => (
                    <div key={r.id} style={{ padding: '14px', border: `1px solid ${FLAG_LEVELS[r.flag]?.color}20`, background: `${FLAG_LEVELS[r.flag]?.color}04` }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                        <div style={{ fontSize: 9, color: FLAG_LEVELS[r.flag]?.color, letterSpacing: '0.2em', textTransform: 'uppercase' }}>{FLAG_LEVELS[r.flag]?.label}</div>
                        <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.2)' }}>{new Date(r.created_at).toLocaleDateString('en-GB')}</div>
                      </div>
                      <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.5)', lineHeight: 1.5 }}>{r.summary || r.encounter_type || 'Recorded encounter'}</div>
                      {r.badge_number && <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.2)', marginTop: 6 }}>Badge: {r.badge_number}</div>}
                      {r.complaint_worthy && <div style={{ fontSize: 9, color: '#fcd34d', marginTop: 6, letterSpacing: '0.2em' }}>⚡ COMPLAINT RECOMMENDED</div>}
                      <div style={{ fontSize: 9, color: 'rgba(255,255,255,0.15)', marginTop: 6, letterSpacing: '0.15em', textTransform: 'uppercase' }}>{r.status}</div>
                    </div>
                  ))}
                </>
              )}
            </div>
          )}
        </div>

        {/* FOOTER */}
        <div style={{ padding: '12px 20px', borderTop: '1px solid rgba(255,255,255,0.04)', display: 'flex', justifyContent: 'space-between', fontSize: 8, color: 'rgba(255,255,255,0.1)', letterSpacing: '0.2em' }}>
          <span>GROUNDLEVEL · NOT LEGAL ADVICE</span>
          <span>KNOW YOUR RIGHTS</span>
        </div>
      </div>
    </>
  )
}

const labelStyle = { fontSize: 9, letterSpacing: '0.3em', color: 'rgba(255,255,255,0.3)', marginBottom: 6, textTransform: 'uppercase' }
const inputStyle = { width: '100%', padding: '12px 14px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', color: '#fff', fontSize: 13, outline: 'none', boxSizing: 'border-box' }
